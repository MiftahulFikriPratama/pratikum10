<?php
class mahasiswa_model extends CI_Model {
    private $table = 'mahasiswa';

    public function getAll(){
      $query = $this->db->get($this->table);
      return $query->result();
 }
}
?>