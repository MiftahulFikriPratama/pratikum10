<?php
defined('BASEPATH') OR exit('No direct script access allowe
d');
class dosen extends CI_Controller {
 public function index() 
 {
 $this->load->model('dosen_model', 'dsn');
 $this->dsn->id=23;
 $this->dsn->nama='sirojul munir';
 $this->dsn->nidn='0325594';
 $this->dsn->gender='L';
 $this->dsn->tmp_lahir='depok';
 $this->dsn->tgl_lahir='23-01-23';
 $this->dsn->pendidikan='S2 Sistem Informasi';
 $list_dsn = [$this->dsn];
 $data['list_dsn']=$list_dsn;
 //$this->load->view('header');
 
 //$this->load->view('footer');
 $this->load->view('layout/header');
 $this->load->view('layout/sidebar');
 $this->load->view('dosen/index', $data);
 $this->load->view('layout/footer');
 }

 public function create (){
    $data["judul"] = "Form Kelola Dosen";
    $this->load->view('layout/header');
    $this->load->view('layout/sidebar');
    $this->load->view('dosen/create', $data);
    $this->load->view('layout/footer');
 }
 public function save (){
    $this->load->model('dosen_model', 'dsn');
    $this->dsn->nama = $this->input->post('nama');
    $this->dsn->nidn = $this->input->post('nidn');
    $this->dsn->gender = $this->input->post('gender');
    $this->dsn->tmp_lahir = $this->input->post('tmp_lahir');
    $this->dsn->tgl_lahir = $this->input->post('tgl_lahir');
    $this->dsn->pendidikan = $this->input->post('pendidikan');
 
    $data['dsn'] = $this->dsn;
    $this->load->view('layout/header');
    $this->load->view('layout/sidebar');
    $this->load->view('dosen/view', $data);
    $this->load->view('layout/footer');
 }
 }